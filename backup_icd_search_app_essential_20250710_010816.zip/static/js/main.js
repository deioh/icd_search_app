// Helper function to highlight matches
const highlightMatches = (text, query) => {
    if (!query) return text;
    const regex = new RegExp(`(${query.split(' ').join('|')})`, 'gi'); // Case-insensitive, global, for multiple words
    return text.replace(regex, '<span class="highlight">$&</span>');
};

// --- Live Search Logic ---
const searchInput = document.getElementById('search-input');
const searchResultsContainer = document.getElementById('search-results-container');

let debounceTimer;

const fetchSearchResults = async (query) => {
    if (query.length === 0) {
        searchResultsContainer.innerHTML = `
            <div class="initial-state">
                <p>Enter a medical term or condition to begin your search.</p>
            </div>
        `;
        return;
    }

    try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();

        if (data.error) {
            searchResultsContainer.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                        </svg>
                    </div>
                    <h3 class="empty-state-title">An Error Occurred</h3>
                    <p class="empty-state-message">${data.error}</p>
                </div>
            `;
        } else if (data.results && data.results.length > 0) {
            let resultsHtml = '<div class="results-grid">';
            data.results.forEach(result => {
                const highlightedDescription = highlightMatches(result.description, query);
                const highlightedCode = highlightMatches(result.code, query);
                resultsHtml += `
                    <div class="result-card">
                        <div class="card-content">
                            <p class="card-category">${result.category}</p>
                            <h3 class="card-description">${highlightedDescription}</h3>
                        </div>
                        <div class="card-footer">
                            <p class="card-code">${highlightedCode}</p>
                        </div>
                    </div>
                `;
            });
            resultsHtml += '</div>';
            searchResultsContainer.innerHTML = resultsHtml;
        } else {
            searchResultsContainer.innerHTML = `
                <div class="empty-state">
                     <div class="empty-state-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                        </svg>
                    </div>
                    <h3 class="empty-state-title">No Results Found</h3>
                    <p class="empty-state-message">Your search for "${query}" did not return any results. Try adjusting your search terms.</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error fetching search results:', error);
        searchResultsContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                    </svg>
                </div>
                <h3 class="empty-state-title">Network Error</h3>
                <p class="empty-state-message">Could not connect to the server. Please check your internet connection or try again later.</p>
            </div>
        `;
    }
};

if (searchInput) {
    searchInput.addEventListener('input', (event) => {
        clearTimeout(debounceTimer);
        const query = event.target.value;
        debounceTimer = setTimeout(() => {
            fetchSearchResults(query);
        }, 300); // Debounce for 300ms
    });

    // Initial load: if there's a query in the URL (e.g., from a refresh), perform search
    const urlParams = new URLSearchParams(window.location.search);
    const initialQuery = urlParams.get('q');
    if (initialQuery) {
        searchInput.value = initialQuery; // Set input value from URL
        fetchSearchResults(initialQuery);
    } else {
        // Display initial state if no query
        searchResultsContainer.innerHTML = `
            <div class="initial-state">
                <p>Enter a medical term or condition to begin your search.</p>
            </div>
        `;
    }
}

document.addEventListener('DOMContentLoaded', () => {
  // --- Theme Toggle Logic ---
  const themeToggle = document.getElementById('theme-toggle');
  
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const docElement = document.documentElement;
      // Toggle the 'dark' class on the <html> element
      docElement.classList.toggle('dark');
      
      // Determine the new theme and save it to localStorage
      const newTheme = docElement.classList.contains('dark') ? 'dark' : 'light';
      localStorage.setItem('theme', newTheme);
    });
  }

  // --- Manage Page Modal Logic ---
  const editModal = document.getElementById('edit-modal');
  // Define closeModal outside the if (editModal) block but within DOMContentLoaded
  const closeModal = () => {
      if (editModal) { // Ensure editModal exists before trying to access its style
          editModal.style.display = 'none';
      }
  };

  if (editModal) {
    const editForm = document.getElementById('edit-form');
    const editButtons = document.querySelectorAll('.edit-btn');
    const closeModalBtn = document.getElementById('modal-close-btn');
    const cancelModalBtn = document.getElementById('modal-cancel-btn');

    const codeInput = document.getElementById('edit-code');
    const descriptionInput = document.getElementById('edit-description');
    const categoryInput = document.getElementById('edit-category');

    const openModal = (event) => {
        const button = event.currentTarget;
        const id = button.dataset.id;
        const code = button.dataset.code;
        const description = button.dataset.description;
        const category = button.dataset.category;

        // Set form action URL
        editForm.action = `/manage/edit/${id}`;

        // Populate form fields
        codeInput.value = code;
        descriptionInput.value = description;
        categoryInput.value = category;
        
        // Show the modal
        editModal.style.display = 'flex';
    };

    editButtons.forEach(button => {
        button.addEventListener('click', openModal);
    });

    closeModalBtn.addEventListener('click', closeModal);
    cancelModalBtn.addEventListener('click', closeModal);
    
    // Also close modal if user clicks on the overlay
    editModal.addEventListener('click', (event) => {
        if (event.target === editModal) {
            closeModal();
        }
    });

    // Handle Save Changes button click
    const saveChangesBtn = document.getElementById('save-changes-btn');
    if (saveChangesBtn) {
        saveChangesBtn.addEventListener('click', async (event) => {
            event.preventDefault(); // Prevent default form submission

            const id = editForm.action.split('/').pop(); // Extract ID from form action
            console.log('editForm:', editForm); // ADD THIS LINE
            // Get input values directly from the document when the button is clicked
            const codeInputEl = document.getElementById('edit-code');
            const descriptionInputEl = document.getElementById('edit-description');
            const categoryInputEl = document.getElementById('edit-category');
            const csrfTokenInputEl = document.querySelector('#edit-form input[name="csrf_token"]'); // Still query within form for CSRF

            console.log('codeInputEl:', codeInputEl);
            console.log('descriptionInputEl:', descriptionInputEl);
            console.log('categoryInputEl:', categoryInputEl);
            console.log('csrfTokenInputEl:', csrfTokenInputEl);

            const code = codeInputEl ? codeInputEl.value : '';
            const description = descriptionInputEl ? descriptionInputEl.value : '';
            const category = categoryInputEl ? categoryInputEl.value : '';
            const csrfToken = csrfTokenInputEl ? csrfTokenInputEl.value : '';

            const formData = new FormData();
            formData.append('code', code);
            formData.append('description', description);
            formData.append('category', category);
            formData.append('csrf_token', csrfToken);

            try {
                const response = await fetch(`/manage/edit/${id}`, {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json(); // Assuming Flask returns JSON for flash messages

                if (response.ok) {
                    // Handle success (e.g., flash message, close modal, refresh page)
                    // For simplicity, let's just refresh the page for now
                    window.location.reload();
                } else {
                    // Handle errors (e.g., display error messages)
                    console.error('Error saving ICD code:', data.error || response.statusText);
                    alert('Error saving ICD code: ' + (data.error || response.statusText));
                }
            } catch (error) {
                console.error('Network error:', error);
                alert('Network error: Could not connect to server.');
            }
        });
    }
  }
});