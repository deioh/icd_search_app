import zipfile
import os
import datetime

def create_zip_archive_selective(source_files_and_dirs, output_zip_path):
    with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for item in source_files_and_dirs:
            if os.path.isfile(item):
                zipf.write(item, item) # Add file directly
            elif os.path.isdir(item):
                for root, _, files in os.walk(item):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, os.getcwd()) # Store relative path
                        zipf.write(file_path, arcname)

if __name__ == "__main__":
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"backup_icd_search_app_essential_{timestamp}.zip"
    output_zip_path = os.path.join("backups", output_filename) # Place in backups folder

    # List of essential files and directories
    essential_items = [
        'app.py',
        'requirements.txt',
        'run-server.bat',
        'config',
        'instance',
        'logs',
        'static',
        'templates',
        'create_backup.py',
        'DEV_README.md',
        'README.md',
        '.gitignore'
    ]

    # Create the backups directory if it doesn't exist
    os.makedirs("backups", exist_ok=True)

    create_zip_archive_selective(essential_items, output_zip_path)
    print(f"Essential backup created at: {output_zip_path}")