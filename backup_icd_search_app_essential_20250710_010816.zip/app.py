import os
import socket
import logging
from logging.handlers import RotatingFileHandler

from flask import Flask, render_template, request, redirect, url_for, flash, get_flashed_messages, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import and_
from flask_wtf import CSRFProtect, FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo, Length
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder='templates/web_app/templates')
app.logger.info('Application startup', event='startup')
app.secret_key = os.urandom(24)
csrf = CSRFProtect(app)

# Configure Flask's logger to write to a file
log_file_path = os.path.join(app.root_path, 'logs', 'app.log')
file_handler = RotatingFileHandler(log_file_path, maxBytes=1024 * 1024, backupCount=5)
file_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
app.logger.addHandler(file_handler)



# Configure a specific logger for edit actions
edit_log_handler = logging.FileHandler(os.path.join(app.root_path, 'logs', 'icd_edit_log.txt'))
edit_log_handler.setLevel(logging.INFO)
edit_formatter = logging.Formatter('%(asctime)s - %(message)s')
edit_log_handler.setFormatter(edit_formatter)
edit_logger = logging.getLogger('icd_edit')
edit_logger.addHandler(edit_log_handler)
edit_logger.setLevel(logging.INFO)


import time
import json


with open(os.path.join(app.root_path, 'config', 'settings.json')) as config_file:
    config_data = json.load(config_file)
    app.config.update(config_data)

# Explicitly set SQLALCHEMY_DATABASE_URI to an absolute path
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(app.instance_path, 'icdcodes.db')}"


db = SQLAlchemy(app)

# Define the User model for authentication
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Define the login form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

# Command to create a default admin user
@app.cli.command("create-admin")
def create_admin():
    """Creates a default admin user."""
    with app.app_context():
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin = User(username='admin')
            admin.set_password('admin')  # Change this in a production environment!
            db.session.add(admin)
            db.session.commit()
            print("Admin user created.")
        else:
            print("Admin user already exists.")

# Define the ICDCode ORM model
class ICDCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    description = db.Column(db.String(500), nullable=False)
    category = db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return f'<ICDCode {self.code}>'

# Define the form for adding/editing ICD codes
class ICDCodeForm(FlaskForm):
    code = StringField('ICD Code', validators=[DataRequired(), Length(max=20)])
    description = StringField('Description', validators=[DataRequired(), Length(max=500)])
    category = StringField('Category (Optional)', validators=[Length(max=100)])
    submit = SubmitField('Submit')

# Create database tables if they don't exist
with app.app_context():
    db.create_all()
    print("Database tables created/checked.")

# Basic search endpoint
@app.route('/search')
def search():
    query = request.args.get('q', '')

    results = []
    error = None

    if query:
        start_time = time.perf_counter()
        search_terms = query.split()
        filters = []
        for term in search_terms:
            filters.append(
                (ICDCode.code.ilike(f'%{term}%')) |
                (ICDCode.description.ilike(f'%{term}%'))
            )
        
        if filters:
            try:
                icd_results = ICDCode.query.filter(and_(*filters)).all()
                results = icd_results
                end_time = time.perf_counter()
                duration = (end_time - start_time) * 1000

                app.logger.info(
                    'Search performed',
                    query=query,
                    num_results=len(results),
                    duration_ms=f"{duration:.2f}",
                    source='frontend_search_page'
                )
            except Exception as e:
                error = "An error occurred while performing the search. Please try again later."
                app.logger.error('Search error', query=query, error_message=str(e), source='frontend_search_page')
    
    return render_template('index.html', query=query, results=results, error=error)

@app.route('/api/search')
def api_search():
    query = request.args.get('q', '')
    results_data = []
    error_message = None

    if query:
        start_time = time.perf_counter()
        search_terms = query.split()
        filters = []
        for term in search_terms:
            filters.append(
                (ICDCode.code.ilike(f'%{term}%')) |
                (ICDCode.description.ilike(f'%{term}%'))
            )
        
        if filters:
            try:
                icd_results = ICDCode.query.filter(and_(*filters)).all()
                for icd_entry in icd_results:
                    results_data.append({
                        'id': icd_entry.id,
                        'code': icd_entry.code,
                        'description': icd_entry.description,
                        'category': icd_entry.category
                    })
                end_time = time.perf_counter()
                duration = (end_time - start_time) * 1000

                app.logger.info(
                    'API Search performed',
                    query=query,
                    num_results=len(results_data),
                    duration_ms=f"{duration:.2f}",
                    source='api_endpoint'
                )
            except Exception as e:
                error_message = "An error occurred while performing the search. Please try again later."
                app.logger.error('API Search error', query=query, error_message=str(e), source='api_endpoint')
    
    return jsonify(results=results_data, error=error_message, query=query)

@app.route('/')
def index():
    app.logger.info('Route accessed', route='/', method='GET')
    return render_template('index.html', query='', results=[])

@app.route('/get_one_icd')
def get_one_icd():
    icd_entry = ICDCode.query.first()
    print(f"Attempting to retrieve ICD entry. Result: {icd_entry}")
    if icd_entry:
        return f"Found ICD Entry: Code - {icd_entry.code}, Description - {icd_entry.description}"
    else:
        return "No ICD entries found in the database."

# Management Interface Routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            session['user_logged_in'] = True
            session['username'] = user.username
            flash('You have been logged in!', 'success')
            return redirect(url_for('manage_icd_codes'))
        else:
            flash('Invalid username or password', 'error')
    else: # Add this else block to log form errors
        if not form.errors: # If form.errors is empty, log the raw form data
            app.logger.warning(f"Login form validation failed with no specific errors. Raw form data: {request.form}")
        else:
            app.logger.warning(f"Login form validation failed: {form.errors}")
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"Error in {getattr(form, field).label.text}: {error}", 'error')
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    session.pop('user_logged_in', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/manage')
def manage_icd_codes():
    form = ICDCodeForm()
    if not session.get('user_logged_in'):
        return redirect(url_for('login'))
        
    query = request.args.get('query', '')
    page = request.args.get('page', 1, type=int)
    per_page = 10  # Number of entries per page

    if query:
        # Search for codes or descriptions matching the query
        results = ICDCode.query.filter(
            (ICDCode.code.ilike(f'%{query}%')) |
            (ICDCode.description.ilike(f'%{query}%'))
        ).paginate(page=page, per_page=per_page, error_out=False)
    else:
        results = ICDCode.query.paginate(page=page, per_page=per_page, error_out=False)

    return render_template('manage.html', 
                           entries=results.items, 
                           pagination=results, 
                           query=query,
                           user_logged_in=session.get('user_logged_in'),
                           username=session.get('username'),
                           form=form)

@app.route('/manage/add', methods=['POST'])
def add_icd_code():
    form = ICDCodeForm()
    if form.validate_on_submit():
        code = form.code.data
        description = form.description.data
        category = form.category.data

        try:
            new_code = ICDCode(code=code, description=description, category=category)
            db.session.add(new_code)
            db.session.commit()
            flash('ICD Code added successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding ICD Code: {e}', 'error')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"Error in {getattr(form, field).label.text}: {error}", 'error')
    return redirect(url_for('manage_icd_codes'))

@app.route('/manage/edit/<int:id>', methods=['POST'])
def edit_icd_code(id):
    icd_entry = ICDCode.query.get_or_404(id)
    form = ICDCodeForm()
    username = session.get('username', 'anonymous')

    if form.validate_on_submit():
        try:
            icd_entry.code = form.code.data
            icd_entry.description = form.description.data
            icd_entry.category = form.category.data
            db.session.commit()
            edit_logger.info(f"action: edit, code: {icd_entry.code}, user: {username}, result: success")
            return jsonify(success=True, message='ICD Code updated successfully!')
        except Exception as e:
            db.session.rollback()
            edit_logger.error(f"action: edit, code: {icd_entry.code}, user: {username}, result: failure, reason: {e}")
            return jsonify(success=False, error=f'Error updating ICD Code: {e}'), 500
    else:
        errors = {field: error_list for field, error_list in form.errors.items()}
        edit_logger.warning(f"action: edit, code: {icd_entry.code}, user: {username}, result: failure, reason: Validation failed - {errors}")
        return jsonify(success=False, error='Validation failed', errors=errors), 400

@app.route('/manage/delete/<int:id>', methods=['POST'])
def delete_icd_code(id):
    icd_entry = ICDCode.query.get_or_404(id)
    try:
        db.session.delete(icd_entry)
        db.session.commit()
        flash('ICD Code deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting ICD Code: {e}', 'error')
    return redirect(url_for('manage_icd_codes'))



if __name__ == '__main__':
    # Get dynamic LAN IP
    hostname = socket.gethostname()
    try:
        lan_ip = socket.gethostbyname(hostname)
    except socket.gaierror:
        lan_ip = "127.0.0.1" # Fallback to localhost if unable to get LAN IP

    print(f"* Running on http://{lan_ip}:5000/")
    app.run(host='0.0.0.0', port=5000, debug=app.config['DEBUG'])