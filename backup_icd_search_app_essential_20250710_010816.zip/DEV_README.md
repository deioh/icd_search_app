# Developer README - ICD Search Application

This document provides technical details and insights into the development and build process of the ICD Search Application.

## Project Overview

The ICD Search Application is a Flask-based web application designed for efficient ICD code lookup and management. It leverages Flask for the backend, SQLAlchemy for database interactions (SQLite), and a combination of Jinja2 templates with vanilla JavaScript for the frontend.

## Development Environment Setup

1.  **Prerequisites:**
    *   Python 3.8+
    *   `pip` (Python package installer)
    *   Git

2.  **Initial Setup:**
    ```bash
    # Clone the repository
    git clone [YOUR_REPOSITORY_URL]
    cd icd_search_app

    # Install Python dependencies
    pip install -r requirements.txt

    # Create a default admin user (for development/testing)
    flask create-admin
    ```

## Build and Run

The application is primarily run using `app.py`. For convenience on Windows, `run-server.bat` is provided.

*   **Running the Flask Development Server:**
    ```bash
    # On Windows
    run-server.bat

    # On other OS or direct Python execution
    python app.py
    ```
    The server will typically run on `http://127.0.0.1:5000/` or your local LAN IP.

## Key Technologies & Architecture

*   **Backend:** Flask (Python)
    *   **Database:** SQLAlchemy with SQLite (`icdcodes.db`)
    *   **Forms & CSRF Protection:** Flask-WTF
    *   **Logging:** Python's standard `logging` module with `RotatingFileHandler` for log rotation.
*   **Frontend:** Jinja2 Templates, Vanilla JavaScript, CSS
    *   **Search Functionality:** Implemented with client-side JavaScript making AJAX calls to `/api/search`.
    *   **Manage Page Modals:** Vanilla JavaScript handles opening/closing modals and dynamic form action setting.
    *   **Form Submission (Edit):** AJAX (`fetch` API) is used for submitting edit form data, including CSRF tokens.
    *   **Form Submission (Add/Delete):** Standard HTML form submissions are used, with CSRF tokens handled by `form.hidden_tag()`.

## Build Details & Troubleshooting Insights

During development, several key issues were identified and resolved:

1.  **`ModuleNotFoundError` for `python_json_logger`:**
    *   **Issue:** Persistent `ModuleNotFoundError` despite package being reported as installed.
    *   **Resolution:** The dependency was removed, and standard Python `logging.Formatter` with `RotatingFileHandler` was implemented for application logging. This suggests a deep-seated environment issue specific to that package.
2.  **JavaScript Errors on Manage Page:**
    *   **Issue:** `Uncaught ReferenceError: closeModal is not defined` and `TypeError: Cannot read properties of null (reading 'value')`.
    *   **Resolution:** `closeModal` function scope was corrected. Input element retrieval in JavaScript was made more robust by querying elements directly within the `saveChangesBtn` listener.
3.  **CSRF Token Missing Errors:**
    *   **Issue:** "Bad Request: The CSRF token is missing" for add, edit, and delete operations.
    *   **Resolution:** Ensured `form.hidden_tag()` was correctly used in `manage.html` for all forms (add, edit modal, delete). For the edit modal, the form submission was converted to an AJAX `fetch` request, explicitly including the CSRF token. Flask backend was modified to return JSON responses for AJAX calls.
4.  **Excessive Backup Time:**
    *   **Issue:** Backup process taking extremely long (e.g., 600 seconds).
    *   **Resolution:** The `create_backup.py` script was modified to exclude the `backups` directory itself, preventing recursive zipping of previous archives.

## Future Enhancements

*   Implement a "Forgot Password" functionality with email sending.
*   Explore more advanced logging solutions (e.g., Grafana Loki) for centralized log management in larger deployments.
*   Add comprehensive unit and integration tests.
