import os
import socket
from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, template_folder='templates/web_app/templates')
import json

with open(os.path.join(app.root_path, 'config', 'settings.json')) as config_file:
    config_data = json.load(config_file)
    app.config.update(config_data)

# Explicitly set SQLALCHEMY_DATABASE_URI to an absolute path
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(app.instance_path, 'icdcodes.db')}"


db = SQLAlchemy(app)

# Define the ICDCode ORM model
class ICDCode(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    description = db.Column(db.String(500), nullable=False)
    category = db.Column(db.String(100), nullable=True)

    def __repr__(self):
        return f'<ICDCode {self.code}>'

# Create database tables if they don't exist
with app.app_context():
    db.create_all()
    print("Database tables created/checked.")

# Basic search endpoint
@app.route('/search')
def search():
    query = request.args.get('q', '')
    if query:
        # Search for codes or descriptions matching the query
        results = ICDCode.query.filter(
            (ICDCode.code.ilike(f'%{query}%')) |
            (ICDCode.description.ilike(f'%{query}%'))
        ).all()
    else:
        results = []
    return render_template('index.html', query=query, results=results)

@app.route('/')
def index():
    return render_template('index.html', query='', results=[])

@app.route('/get_one_icd')
def get_one_icd():
    icd_entry = ICDCode.query.first()
    print(f"Attempting to retrieve ICD entry. Result: {icd_entry}")
    if icd_entry:
        return f"Found ICD Entry: Code - {icd_entry.code}, Description - {icd_entry.description}"
    else:
        return "No ICD entries found in the database."



if __name__ == '__main__':
    # Get dynamic LAN IP
    hostname = socket.gethostname()
    try:
        lan_ip = socket.gethostbyname(hostname)
    except socket.gaierror:
        lan_ip = "127.0.0.1" # Fallback to localhost if unable to get LAN IP

    print(f"* Running on http://{lan_ip}:5000/")
    app.run(host='0.0.0.0', port=5000, debug=app.config['DEBUG'])
