import sys

def main():
    print("ICD Search App CLI")
    print("Use 'python app.py' to run the web application.")

if __name__ == "__main__":
    main()
