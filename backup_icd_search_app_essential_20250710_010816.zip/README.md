# ICD Search Application

This is a Flask-based web application for fast and reliable International Classification of Diseases (ICD) code lookup and management.

## Features

*   **ICD Code Search:** Quickly find ICD codes by code or description on the main page.
*   **Comprehensive Management Interface:**
    *   **Add New Codes:** Easily add new ICD codes with descriptions and categories.
    *   **Edit Existing Codes:** Modify code details through an intuitive modal interface.
    *   **Delete Codes:** Remove codes from the database.
    *   **Search & Filter:** Efficiently search and filter codes on the manage page.
    *   **Pagination:** Browse through large datasets of ICD codes with pagination.
*   **User Authentication:** Secure login for accessing the management features.
*   **Improved Logging:** Application logs are now managed with rotation, aiding in debugging and monitoring.

## Setup

1.  **Clone the repository:**
    ```bash
    git clone [YOUR_REPOSITORY_URL]
    cd icd_search_app
    ```
2.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
3.  **Create a default admin user (first time only):**
    ```bash
    flask create-admin
    ```
    (Default username: `admin`, password: `admin` - **Change this in a production environment!**)
4.  **Run the application:**
    *   **Windows:**
        ```bash
        run-server.bat
        ```
    *   **Other OS (or if `run-server.bat` is not preferred):**
        ```bash
        python app.py
        ```

## Usage

*   **Access the Application:** Open your web browser and navigate to the displayed LAN IP address (e.g., `http://192.168.X.X:5000/`).
*   **Search ICD Codes (Main Page):** Enter your search query in the search bar and press Enter.
*   **Manage ICD Codes:**
    *   Navigate to the `/manage` endpoint (e.g., `http://192.168.X.X:5000/manage`).
    *   Log in with your admin credentials.
    *   Use the "Add New ICD Code" form to add entries.
    *   Use the "Edit" and "Delete" buttons next to existing codes.
    *   Utilize the search bar and pagination controls to navigate the code list.

## Project Structure

```
.
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── run-server.bat          # Windows batch script to run the server
├── config/                 # Application configuration
│   └── settings.json
├── instance/               # Instance-specific data (e.g., SQLite database)
│   └── icdcodes.db
├── logs/                   # Application logs
│   ├── app.log
│   └── icd_edit_log.txt
├── static/                 # Static files (CSS, JS)
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
└── templates/              # Jinja2 templates
    └── web_app/
        └── templates/
            ├── index.html
            ├── login.html
            └── manage.html
```