// Basic JavaScript for the ICD Search App
console.log("ICD Search App loaded.");
